## K Means algorithm
library(stats)
k.means = function(data,clusters,iterations=10,distmethod="euclidean"){
  n = clusters
  centroids = as.data.frame(data[sample(nrow(data),n),])
  clusterhistory <- vector(iterations, mode="list")
  centroidhistory <- vector(iterations, mode="list")

  distance = data.frame()
  for(k in 1:iterations){
    if(ncol(data)==1){
        for(j in 1:nrow(centroids)){
          for (i in 1:nrow(data)) {
            distance[i,j]=as.double(stats::dist(rbind(data[i,],centroids[j,1]),method = distmethod))
          }
        }
      }
    else{
      for(j in 1:nrow(centroids)){
        for (i in 1:nrow(data)) {
          distance[i,j]=as.double(stats::dist(rbind(data[i,],centroids[j,]),method = distmethod))
        }
      }
    }
    cluster = vector()
    for(i in 1:nrow(distance)){
      cluster[i] = names(distance)[which.min(apply(distance[i,],MARGIN=2,min))]
    }
    clusterhistory[[k]] = cluster
    centroidhistory[[k]] = centroids
    data = cbind(data,cluster)
    centroids = within((stats::aggregate(.~ data$cluster, data, mean)),rm("cluster","data$cluster"))
    data = within(data,rm("cluster"))
    k = k+1
  }
  finalclusters = clusterhistory[[iterations]]
  clusterdata=cbind(data,finalclusters)
  size = stats::aggregate(x=clusterdata$finalclusters,list(Cluster = clusterdata$finalclusters), length) #size of cluster
  list(clusterdata,centroidhistory,clusterhistory,centroids,size) #Output
}
