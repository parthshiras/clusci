#Number of clusters

#Plot elbow curve
elbow.curve.plot = function(data,maxclusters){
  wss = (nrow(data)-1)*sum(apply(data,2,stats::var))
  for (i in 2:maxclusters) wss[i] = sum(stats::kmeans(data, centers=i)$withinss)
  graphics::plot(1:maxclusters, wss, type="b", xlab="Number of Clusters", ylab="Variance between the clusters")
}
