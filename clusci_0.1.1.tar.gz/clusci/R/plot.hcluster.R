# Hierarchical cluster plot

#Using a simple plot function to visualize the clustering output

plot.hcluster = function(hcluster){
  print(graphics::plot(hcluster))
}
