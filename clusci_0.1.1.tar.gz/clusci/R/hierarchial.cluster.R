#Hierarchical clustering

hierarchical.cluster = function(data, method=c("complete","median","average","single")){
  # The following function is used to order the elements for the hclust plot
  # The same has been adopted directly from the original Fortran code used by R in hclust function
  # It's only needed by the plotting routine to avoid crossing connections.
  iorder = function(m)
  {
    N = nrow(m) + 1
    iorder = rep(0,N)
    iorder[1] = m[N-1,1]
    iorder[2] = m[N-1,2]
    loc = 2
    for(i in seq(N-2,1))
    {
      for(j in seq(1,loc))
      {
        if(iorder[j] == i)
        {
          iorder[j] = m[i,1]
          if(j==loc)
          {
            loc = loc + 1
            iorder[loc] = m[i,2]
          } else
          {
            loc = loc + 1
            for(k in seq(loc, j+2)) iorder[k] = iorder[k-1]
            iorder[j+1] = m[i,2]
          }
        }
      }
    }
    -iorder
  }


  #Algorithm for heirarchical clustering
  distance = data.frame() #Creating a dataframe to calculate distances for every element
  data$ID = seq(from =1 , to = nrow(data), by =1) #Creating an ID column to identify each row separately
  for(j in 1:nrow(data)){
    for (i in 1:nrow(data)) {
      distance[i,j]=as.double(stats::dist(rbind(data[i,],data[j,]),method = "euclidean"))
    }
  } #Calculating distances for each element from other element and creating a n*n matrix
  distance = as.matrix(distance) #Converting to matrix form
  method = switch(match.arg(method), complete = max, median  = stats::median, average  = mean, single   = min) #Selecting the method for calculating distances for clustering

  N = nrow(distance)
  diag(distance) = Inf #Converting all diagonals to infinity because we want to exclude them from distance calculations
  n = seq(from = -1, to = -N, by = -1) # Tracking the number of clusters. If we have 50 elements,we will have 50 clusters
  mergeoutput = matrix(0,nrow=N-1, ncol=2) #Output of hierarchical clustering, pairs of elements
  clusterheight = rep(0,N-1) #Height of the cluster will be equal to total number of elements - 1
  for(i in 1:(N-1)){
    clusterheight[i] = min(distance) #Finding the minimum distance between all elements
    j = which(distance - clusterheight[i] == 0, arr.ind=TRUE) #Finding the elements with lowest distance in our matrix
    j = j[1,,drop=FALSE] #We will cluster only 2 elements at a time, so we drop the other pairs if found
    pair = n[j] # Finding the pair in our tracking list
    pair = pair[order(pair)]
    mergeoutput[i,] = pair
    group = c(j, which(n %in% n[j[1,n[j]>0]])) #Agglomerating this into the groups that the pair belongs to
    n[group] = i
    r = apply(distance[j,],2,method)
    distance[min(j),] = distance[,min(j)] = r #Considering the next least distance, by modifying the matrix
    distance[min(j),min(j)]        = Inf #We remove the pair we considered in this iteration
    distance[max(j),] = distance[,max(j)] = Inf
  }

  structure(list(merge = mergeoutput, height = clusterheight, order = iorder(mergeoutput),
                 labels = rownames(distance), #method = method,
                 call = match.call(), dist.method = "euclidean"),
            class = "hclust")
}
